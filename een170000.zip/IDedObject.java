/*
 * Ethan Newman
 * EEN170000
 * CS 3345.005
 * The task of this project is to implement in Java a singly linked list of a specific generic type.
 */


//IDed Object interface
public interface IDedObject
{
    //returns the ID of the Object
    int getID();

    //prints the details of the ID
    String printID();

}