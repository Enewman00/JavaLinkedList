Ethan Newman
EEN170000
Project 2
Files - IDedObject.java, MyItem.java, IDedLinkedList.java, P2Driver.java
Text Editor - VSCode, compiled through the command line
version - java 11.0.4
compiler options - none
sample commands - javac *.java, java P2Driver data\t2.txt data\r2
 - produces r2 in 'data' directory.

SAMPLE FILES
t2.txt
Insert 22 19 475 1238 9742 0
Insert 12 96 44 109 0
PrintTotal
FindID22
Find 45
PrintTotal
24323  mjbjh kjhkjhkj hjhg 
Insert 56 89 785 587 435 0
PrintTotal
Insert 56 98 34 67 324 0
PrintTotal
Insert 87 547 456 3435 90 0
PrintTotal
DeleteID 
Find 
sdfsdf
FindID 666
End

r2
True
True
34
ERROR
ERROR
34
ERROR
True
90
False
90
True
177
ERROR
ERROR
ERROR
Null
